#!/bin/bash
# Generates a JAR file that can be used from GWT to load Dygraphs

jar -cf dygraph-gwt.jar -C gwt org
